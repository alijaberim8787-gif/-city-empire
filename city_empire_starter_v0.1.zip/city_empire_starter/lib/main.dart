import 'dart:async';
import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:three_js/three_js.dart' as three;

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const CityEmpireApp());
}

class CityEmpireApp extends StatelessWidget {
  const CityEmpireApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'City Empire',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF101820),
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF36C99A),
          brightness: Brightness.dark,
        ),
        useMaterial3: true,
      ),
      home: const CityGameScreen(),
    );
  }
}

class CityGameScreen extends StatefulWidget {
  const CityGameScreen({super.key});

  @override
  State<CityGameScreen> createState() => _CityGameScreenState();
}

class _CityGameScreenState extends State<CityGameScreen> {
  static const int houseCost = 5000;
  static const String saveKey = 'city_empire_save_v1';

  late final three.ThreeJS threeJs;
  final List<three.Object3D> _placedBuildings = [];

  int money = 50000;
  int buildingCount = 0;
  int population = 0;
  String status = 'شهر خودت را بساز';

  double _yaw = math.pi / 4;
  double _distance = 27;
  double _targetX = 0;
  double _targetZ = 0;
  double _startYaw = 0;
  double _startDistance = 27;

  @override
  void initState() {
    super.initState();
    threeJs = three.ThreeJS(
      onSetupComplete: () {
        if (mounted) setState(() {});
      },
      setup: _setupScene,
    );
    _loadGame();
  }

  Future<void> _setupScene() async {
    threeJs.camera = three.PerspectiveCamera(
      42,
      threeJs.width / threeJs.height,
      0.1,
      500,
    );
    threeJs.scene = three.Scene();
    threeJs.scene.background = three.Color(0.72, 0.84, 0.91);

    threeJs.scene.add(three.AmbientLight(0xffffff, 0.75));

    final sun = three.DirectionalLight(0xffffff, 1.2);
    sun.position.setValues(20, 35, 15);
    threeJs.scene.add(sun);

    _addBox(
      x: 0, y: -0.35, z: 0,
      width: 34, height: 0.6, depth: 34,
      color: 0x75A96B,
    );

    // Main roads crossing the starter district.
    _addBox(
      x: 0, y: 0.01, z: 0,
      width: 34, height: 0.08, depth: 3.2,
      color: 0x343B43,
    );
    _addBox(
      x: 0, y: 0.02, z: 0,
      width: 3.2, height: 0.09, depth: 34,
      color: 0x343B43,
    );

    // Simple road lane markings.
    for (int i = -14; i <= 14; i += 4) {
      _addBox(
        x: i.toDouble(), y: 0.075, z: 0,
        width: 1.7, height: 0.025, depth: 0.10,
        color: 0xFFD76A,
      );
      _addBox(
        x: 0, y: 0.075, z: i.toDouble(),
        width: 0.10, height: 0.025, depth: 1.7,
        color: 0xFFD76A,
      );
    }

    // Starter buildings placed around the central intersection.
    _addBuilding(-7, -7, 0x8FB8D8, 3.0, 5.5);
    _addBuilding(7, -7, 0xE4B66B, 3.2, 4.0);
    _addBuilding(-7, 7, 0xB7C4D1, 3.0, 7.0);
    _addBuilding(7, 7, 0x86B6A0, 3.5, 5.0);

    _updateCamera();
    threeJs.addAnimationEvent((_) {});
  }

  void _addBox({
    required double x,
    required double y,
    required double z,
    required double width,
    required double height,
    required double depth,
    required int color,
  }) {
    final geometry = three.BoxGeometry(width, height, depth);
    final material = three.MeshPhongMaterial({'color': color});
    final mesh = three.Mesh(geometry, material);
    mesh.position.setValues(x, y, z);
    threeJs.scene.add(mesh);
  }

  void _addBuilding(
    double x,
    double z,
    int color,
    double width,
    double height,
  ) {
    _addBox(
      x: x,
      y: height / 2,
      z: z,
      width: width,
      height: height,
      depth: width,
      color: color,
    );

    // Flat rooftop detail.
    _addBox(
      x: x,
      y: height + 0.12,
      z: z,
      width: width * 0.72,
      height: 0.24,
      depth: width * 0.72,
      color: 0x536575,
    );
  }

  void _updateCamera() {
    final horizontal = _distance * math.cos(0.72);
    final y = _distance * math.sin(0.72);
    final x = _targetX + horizontal * math.sin(_yaw);
    final z = _targetZ + horizontal * math.cos(_yaw);
    threeJs.camera.position.setValues(x, y, z);
    threeJs.camera.lookAt(
      three.Vector3(_targetX, 0, _targetZ),
    );
  }

  void _onScaleStart(ScaleStartDetails details) {
    _startYaw = _yaw;
    _startDistance = _distance;
  }

  void _onScaleUpdate(ScaleUpdateDetails details) {
    setState(() {
      if (details.pointerCount >= 2) {
        _yaw = _startYaw + details.rotation;
        _distance = (_startDistance / details.scale).clamp(13.0, 55.0);
      } else {
        // One-finger drag pans the city.
        final panScale = _distance * 0.0022;
        _targetX -= details.focalPointDelta.dx * panScale;
        _targetZ -= details.focalPointDelta.dy * panScale;
      }
      _updateCamera();
    });
  }

  Future<void> _loadGame() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(saveKey);
    if (raw == null) return;

    try {
      final data = jsonDecode(raw) as Map<String, dynamic>;
      if (!mounted) return;
      setState(() {
        money = data['money'] as int? ?? 50000;
        buildingCount = data['buildingCount'] as int? ?? 0;
        population = data['population'] as int? ?? 0;
      });
    } catch (_) {
      // Ignore a damaged save and start a fresh city.
    }
  }

  Future<void> _saveGame() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(saveKey, jsonEncode({
      'money': money,
      'buildingCount': buildingCount,
      'population': population,
      'savedAt': DateTime.now().millisecondsSinceEpoch,
    }));
  }

  Future<void> _buildHouse() async {
    if (money < houseCost) {
      setState(() => status = 'پول کافی برای ساخت خانه نداری');
      return;
    }

    // Temporary placement pattern for the first playable prototype.
    final index = buildingCount;
    final positions = <List<double>>[
      [-12, -12], [12, -12], [-12, 12], [12, 12],
      [-16, -6], [16, -6], [-6, 16], [6, -16],
    ];
    final position = positions[index % positions.length];

    setState(() {
      money -= houseCost;
      buildingCount++;
      population += 12;
      status = 'خانه جدید ساخته شد!';
    });

    _addBuilding(
      position[0],
      position[1],
      0x9CC7E8,
      2.8,
      4.5 + (index % 3) * 1.1,
    );
    await _saveGame();
  }

  @override
  void dispose() {
    threeJs.dispose();
    three.loading.clear();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Stack(
          children: [
            Positioned.fill(
              child: GestureDetector(
                behavior: HitTestBehavior.opaque,
                onScaleStart: _onScaleStart,
                onScaleUpdate: _onScaleUpdate,
                child: threeJs.build(),
              ),
            ),
            Positioned(
              top: 12,
              left: 12,
              right: 12,
              child: _topBar(),
            ),
            Positioned(
              left: 14,
              right: 14,
              bottom: 18,
              child: _buildPanel(),
            ),
            Positioned(
              top: 76,
              left: 14,
              child: _cameraHint(),
            ),
          ],
        ),
      ),
    );
  }

  Widget _topBar() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: BoxDecoration(
        color: const Color(0xE6192732),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: Colors.white12),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          _stat('موجودی', '\$${money.toString()}', Icons.account_balance_wallet),
          _stat('جمعیت', population.toString(), Icons.people_alt),
          _stat('ساختمان', buildingCount.toString(), Icons.apartment),
        ],
      ),
    );
  }

  Widget _stat(String label, String value, IconData icon) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(icon, color: const Color(0xFF52D6A8), size: 19),
        const SizedBox(width: 6),
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(label, style: const TextStyle(fontSize: 10, color: Colors.white70)),
            Text(value, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.bold)),
          ],
        ),
      ],
    );
  }

  Widget _cameraHint() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 8),
      decoration: BoxDecoration(
        color: const Color(0xCC192732),
        borderRadius: BorderRadius.circular(12),
      ),
      child: const Text(
        'یک انگشت: حرکت شهر  •  دو انگشت: چرخش و زوم',
        style: TextStyle(fontSize: 10, color: Colors.white),
      ),
    );
  }

  Widget _buildPanel() {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: const Color(0xF21A2935),
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: Colors.white12),
        boxShadow: const [
          BoxShadow(color: Colors.black38, blurRadius: 18, offset: Offset(0, 8)),
        ],
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(status, style: const TextStyle(fontSize: 12, color: Colors.white70)),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(
                child: FilledButton.icon(
                  onPressed: _buildHouse,
                  icon: const Icon(Icons.add_home_work),
                  label: const Text('ساخت خانه  \$5,000'),
                  style: FilledButton.styleFrom(
                    backgroundColor: const Color(0xFF25A879),
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(vertical: 14),
                  ),
                ),
              ),
              const SizedBox(width: 9),
              IconButton.filledTonal(
                onPressed: () {
                  setState(() {
                    _yaw = math.pi / 4;
                    _distance = 27;
                    _targetX = 0;
                    _targetZ = 0;
                    _updateCamera();
                  });
                },
                icon: const Icon(Icons.center_focus_strong),
                tooltip: 'بازنشانی دوربین',
              ),
            ],
          ),
        ],
      ),
    );
  }
}
